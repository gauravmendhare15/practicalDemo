const UserRoleConstant = Object.freeze({
    Admin: "Admin",
    Member: "Member"
})

module.exports = {
    UserRoleConstant: UserRoleConstant
}